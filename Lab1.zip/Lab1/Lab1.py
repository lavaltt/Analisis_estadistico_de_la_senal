# -*- coding: utf-8 -*-
"""
Editor de Spyder

Laura Valentina Castro-Julian Esteban Giraldo
UMNG
"""

import wfdb #Libreria para lectura de datos de physionet
import matplotlib.pyplot as plt #Libreria para gráficos
import math #Libreria para operaciones matemáticas
import statistics as stt #Libreria para estadística
import numpy as np
from scipy.stats import norm

#Cargar la información(Se debe tener archivo .dad y .hea) 
#NOTA: El proyecto debe estar en la misma carpeta de los archivos

senal = wfdb.rdrecord('04E5E70A-7D79-43AC-A892-8577CD957D99')

#Valores en y
y = senal.p_signal #obtener la señal del objeto record
a = y[:,12] #Seleccionar el canal de la señal, (: toma todas las filas de la columna 12)
tamano = senal.sig_len #Cantidad de muestras de la señal original
datos = len(a) #Muestras del canal elegido
ps = (sum(a**2))/datos #Potencia de la señal elegida(la misma para cada cálculo)

#Menú con instrucciones del programa
print("\nBienvenido a 'Análisis estadístico de la señal´\n Si desea acceder a los datos de la señal, con sus respectivas gráficas presione 1 \n Si desea conocer los cálculos estadísticos presione 2\n Si desea visualizar el histograma de la señal presione 3\n Si desea conocer los datos y gráficas de la señal contaminada con ruido Gaussiano, presione 4\n Si desea conocer los datos y gráficas de la señal contaminada con ruido impulso, presione 5\n Si desea conocer los datos y gráficas de la señal contaminada con ruido artefacto, presione 6")
while True:
    numero = int(input("\nPor favor, ingrese un número:"))
    if numero==1:
        num_columnas = y.shape[1] #Canales de la señal
        num_filas = y.shape[0] #Muestras por canal
        print("Cantidad de canales de la señal original:", num_columnas)
        print("Cantidad de muestras por canal:", num_filas)
        
        #Gráfica de la señal multicanal
        plt.figure(figsize=(12, 6)) #Tamaño de la gráfica
        plt.plot(y) #graficar la señal y
        plt.title("ECG bajo efectos de farmácos para trastornos cardíacos(Señal multicanal)") #Título de la gráfica
        plt.xlabel('Tiempo(s)')
        plt.ylabel('Voltaje(mv)')
        plt.grid(True)#Cuadricula de la gráfica
        
        #Gráfica del canal elegido de la señal multicanal
        plt.figure(figsize=(12, 6))
        plt.plot(a)
        plt.title("Canal elegido de la señal")
        plt.xlabel('Tiempo(s)')
        plt.ylabel('Voltaje(mv)')
        plt.grid(True)
        plt.show()#Mostrar las gráficas
    #%%
#--------------------------CÁLCULOS ESTADÍSTICOS----------------------------
    #Cálculos estadísticos descriptivos programando las fórmulas
        #Media 
    if numero==2:
        print("Ingresa la letra (a) para obtener los cálculos estadísticos por fórmulas, o (b) para obtener los mismos resultados por librerias de python\n")
        letra = str(input("\nPor favor, ingresa una letra: "))
        if letra=='a':
            sumatoria = sum(a) #sumar todos los datos del vector de la señal elegida entre ellos
            media_0 = sumatoria/datos #Hallar la media
            
                #Desviación estándar
            sumaD = sum((x - media_0) ** 2 for x in a) #Para cada x en el conjunto de datos a, se resta la media y se eleva al cuadrado, para sumar cada dato entre ellos
            v = sumaD / (datos - 1)
            desviacion_0 = math.sqrt(v)
            
                #Coeficiente de variación
            coeficiente_0 = desviacion_0 / media_0
            
            #Imprimir todos los cálculos realizados
            print ("La media estadística programando fórmulas es:",media_0)
            print("La desviación estándar programando fórmulas es:",desviacion_0)
            print("El coeficiente de variación programando es:",coeficiente_0)
    #%%
    #Cálculos estadisticos descriptivos usando librerias de python
        if letra=='b':
            media = stt.mean(a) #Hallar la media con la función mean de la libreria a statistics
            desviacion = stt.stdev(a) #Hallar la desviación estándar con la función stdev
            coeficiente = desviacion / media
            
            #Imprimir todos los datos cálculados
            print("La media estadística con funciones es:",media)
            print("La desviacion estándar con funciones es:",desviacion)
            print("El coeficiente de variación con funciones es:",coeficiente)
    #%%
    #HISTOGRAMA
    # Crear el histograma con funciones de python 
    if numero==3:
        plt.figure(figsize=(12, 6)) #Tamaño del encuadre de la gráfica
        plt.hist(a, bins=25, edgecolor='black', alpha=0.7, color='blue') #Usar la función hist de matplotlib y darle los parametros. Bins: Cantidad de intervalos 
        
        # Añadir títulos y etiquetas para la gráfica
        plt.title('Histograma de la señal con funciones de python')
        plt.xlabel('Valor')
        plt.ylabel('Frecuencia')
        plt.grid(True)
        plt.show()
    #%%
    #HISTOGRAMA A MANO 
    
        # Encontrar valores máximo y mínimo de la señal
        valor_max = max(a)
        valor_min = min(a)
        
        # Definir el número de intervalos para el histograma
        num_intervalos = 25
        rango = valor_max - valor_min
        ancho_intervalo = rango / num_intervalos #Tamaño de cada intervalo
        
        # Inicializar las frecuencias
        frecuencias = [0] * num_intervalos #Conteo de datos en un intervalo
        
        # Contar las frecuencias en cada intervalo
        for valor in a:
            indice = int((valor - valor_min) / ancho_intervalo)
            if indice == num_intervalos:  # Asegurarse de que el valor máximo caiga en el último intervalo
                indice -= 1
            frecuencias[indice] += 1
        
        # Mostrar la tabla de frecuencias
        print("Tabla de frecuencias para histograma con fórmulas:")
        for i in range(num_intervalos):
            intervalo_inicio = valor_min + i * ancho_intervalo
            intervalo_fin = intervalo_inicio + ancho_intervalo
            print(f"Intervalo [{intervalo_inicio:.2f}, {intervalo_fin:.2f}): {frecuencias[i]}")
        
        # Graficar el histograma
        plt.figure(figsize=(12, 6))
        plt.hist(a, bins=num_intervalos, edgecolor='black', color='orange')
        plt.xlabel('Valor')
        plt.ylabel('Frecuencia')
        plt.title('Histograma de la señal programando fórmulas')
        plt.grid(True)
        plt.show()
    
    #%%
    #----------------------------CONTAMINACIÓN DE LA SEÑAL--------------------------------
    if numero==4:
        print("\nIngresa la letra (a) para obtener el ruido gaussiano y su normalización(caso 1), o (b) para obtener la normalización (caso 2)\n")
        letra = str(input("Por favor, ingresa una letra: "))
        if letra=='a':
            #Ruido Gaussiano 
            np.random.seed(42) #Graantizar que los números generados aleatoriamente sean siempre los mismos
            ruido_gaussiano = np.random.normal(0, 1, datos)
            muestras_ruido = len(ruido_gaussiano) #Obtener el número de muestras
            
            plt.figure(figsize =(12,6))
            plt.plot(ruido_gaussiano, color='green')
            plt.title('Ruido Gaussiano generado aleatoriamente')
            plt.grid(True)
            
    #%%
            #***********Normalización 1(SNR positivo) del ruido  Gaussiano********
            ruidoGN = (ruido_gaussiano*0.3)/4 #Normalización del ruido a una amplitud más baja. Regla de 3
            muestras_ruidoGN = len(ruidoGN)
            
            #Gráficar el ruido normalizado
            plt.figure(figsize=(12,6))
            plt.plot(ruidoGN, color='green')
            plt.title('Ruido Gaussiano normalizado (caso 1)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido normalizado (caso 1)
            senal_rg = (ruidoGN + a)
            
            #Gráficar la señal con ruido normalizado
            plt.figure(figsize=(12,6))
            plt.plot(senal_rg,color= 'green')
            plt.title('Señal original contaminada con ruido Gussiano normalizado (caso 1)')
            plt.grid(True)
            plt.show()
            
            #Hallar la potencia del ruido para el SNR
            prG = (sum(ruidoGN**2))/muestras_ruidoGN
            b= ps/prG #Razón entre la potencia de la señal y la potencia del ruido
            
            print("La potencia del ruido Gaussiano normalizado (caso 1) es:",prG)
            print("La potencia de la señal es:",ps)
            
            #Cálculo de la relación señal-ruido
            SNRG = 10* math.log10(b)
            print("La relación señal-ruido(SNR), usando ruido Gaussiano normalizado (caso 1) es:", SNRG)
    
    #%%
    #******Normalización 2(SNR negativo) del ruido  Gaussiano***********
        if letra =='b':
            ruidoGN2 = (ruido_gaussiano*1.5)/4 #Normalización del ruido a una amplitud más alta que el caso 1.
            muestras_ruidoGN2 = len(ruidoGN2)
            plt.figure(figsize=(12,6))
            plt.plot(ruidoGN2,color='green')
            plt.title('Ruido Gaussiano normalizado (caso 2)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido normalizado2
            senal_rg2 = (ruidoGN2 + a)
            
            plt.figure(figsize=(12,6))
            plt.plot(senal_rg2,color='green')
            plt.title('Señal original contaminada con ruido Gaussiano normalizado (caso 2)')
            plt.grid(True)
            plt.show()
            
            
            #Hallar la potencia del ruido normalizado (caso 2)
            prG2 = (sum(ruidoGN2**2))/muestras_ruidoGN2
            c = ps/prG2
            
            print("La potencia del ruido Gaussiano normalizado (caso 2) es:",prG2)
     
            
            #Cálculo de la relación señal-ruido
            SNRG2 = 10* math.log10(c)
            print("La relación señal-ruido(SNR), usando ruido Gaussiano normalizado (caso 2) es:", SNRG2)
    
    #%%
    #Ruido impulso
    if numero==5:
       print("\nIngresa la letra (a) para obtener el ruido impulso y su normalización (caso 1), o (b) para obtener la normalización (caso 2)\n")
       letra = str(input("Por favor, ingresa una letra: "))
       if letra=='a':
            prob_impulso = 0.05  # Probabilidad de un impulso
            
            # Crear una señal de ruido impulso
            ruido_impulso = np.zeros(datos) #Arreglo base en el que se agregan los impulsos
            impulsos = np.random.rand(datos) < prob_impulso #Determinar aleatoriamente la posición de los impulsos
            ruido_impulso[impulsos] = np.abs(np.random.randn(np.sum(impulsos))) #Los valores  se asignan a las posiciones seleccionadas.
            
            #Graficar ruido impulso
            plt.figure(figsize=(12, 6))
            plt.plot(ruido_impulso, color="r")
            plt.title("Ruido tipo impulso, generado aleatoriamente")
            plt.grid(True)
            
            #Amplitud de la señal para normalización
            amplitud_maxima = np.max(np.abs(ruido_impulso))
            print("Amplitud Máxima del ruido impulso:", amplitud_maxima)
            
            
            #%%
            #***********Normalización 1(SNR positivo) del ruido impulso********
            ruidoIN = (ruido_impulso*0.6)/3 #Normalización
            plt.figure(figsize=(12,6))
            plt.plot(ruidoIN, color='r')
            plt.title('Ruido impulso normalizado (caso 1)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido impulso normalizado
            senal_ri = ruidoIN + a
            plt.figure(figsize=(12,6))
            plt.plot(senal_ri,color='r')
            plt.title('Señal contaminada con ruido impulso normalizado (caso 1)')
            plt.grid(True)
            plt.show()
            
            #Hallar las potencias
            prI = (sum(ruidoIN**2))/datos
            d = ps/prI
            
            print("La potencia del ruido impulso normalizado (caso 1) es:",prI)

            #Cálculo de la relación señal-ruido
            SNRI = 10* math.log10(d)
            print("La relación señal-ruido(SNR), usando ruido impulso normalizado (caso 1) es:", SNRI)
            #%%
            #***********Normalización 2(SNR negativo) del ruido impulso******* 
       if letra=='b':
            ruidoIN2 = (ruido_impulso*4.5)/3 #Normalización 
            plt.figure(figsize=(12,6))
            plt.plot(ruidoIN2, color='r')
            plt.title('Ruido impulso normalizado (caso 2)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido impulso normalizado
            senal_ri2 = ruidoIN2 + a
            plt.figure(figsize=(12,6))
            plt.plot(senal_ri2,color='r')
            plt.title('Señal contaminada con ruido impulso normalizado (caso 2)')
            plt.grid(True)
            plt.show()
            
            #Hallar las potencias
            prI2 = (sum(ruidoIN2**2))/datos
            e = ps/prI2
            
            print("La potencia del ruido impulso normalizado (caso 2) es:",prI)
            
            #Cálculo de la relación señal-ruido
            SNRI2 = 10* math.log10(e)
            print("La relación señal-ruido(SNR), usando ruido impulso normalizado (caso 2)es:", SNRI2)
    #%%
    if numero==6:
        print("\nIngresa la letra (a) para obtener el ruido artefacto y su normalización (caso 1), o (b) para obtener la normalización (caso 2)\n")
        letra = str(input("Por favor, ingresa una letra: "))
        if letra=='a':
            #Ruido tipo artefacto
            # Parámetros
            dur = 1.0  # Duración en segundos
            fm = 1200  # Frecuencia de muestreo en Hz
            nm = int(dur * fm)  # Número total de muestras
            
            # Generar el vector de tiempo
            t = np.linspace(0, dur, nm, endpoint=False) #Vector que va desde 0, hasta 'dur'(1)
            
            # Generar artefactos
            a_dur = 0.1  # Duración del artefacto en segundos
            a_amplitud = 5.0  # Amplitud del artefacto
            num_a = 10  # Número de artefactos
            ap = np.random.choice(nm, num_a, replace=False) #Donde ubicar los artefactos en la señal
            ruido_artefacto = np.zeros_like(t) #Almacenar la señal con artefactos
            for pos in ap:
                inicio = pos #Calcular inicio y fin de cada artefacto
                fin = min(pos + int(a_dur * fm), nm)
                ruido_artefacto[inicio:fin] = a_amplitud * np.random.normal(size=(fin - inicio)) #Generar valores aleatorios y los asigna a las posiciones determinadas
                
            # Graficar la señal con artefactos
            plt.figure(figsize=(12, 6))
            plt.plot(t, ruido_artefacto, color='purple')
            plt.title('Ruido tipo artefacto generado aleatoriamente')
            plt.grid(True)
            
            
            #%%
            #***********Normalización 1(SNR positivo) del ruido artefacto********
            ruidoAN = (ruido_artefacto*0.2)/14.5 #Normalizacióon
            plt.figure(figsize=(12, 6))
            plt.plot(ruidoAN, color='purple')
            plt.title('Ruido tipo artefacto normalizado (caso 1)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido artefacto normalizado
            senal_ra = ruidoAN + a
            plt.figure(figsize=(12,6))
            plt.plot(senal_ra,color='purple')
            plt.title('Señal contaminada con ruido artefacto normalizado (caso 1)')
            plt.grid(True)
            plt.show()
            
            #Hallar las potencias
            prA = (sum(ruidoAN**2))/datos
            f = ps/prA
            
            print("La potencia del ruido artefacto normalizado (caso 1) es:",prA)
            
            #Cálculo de la relación señal-ruido
            SNRA = 10* math.log10(f)
            print("La relación señal-ruido(SNR), usando ruido artefacto normalizado (caso 1) es:", SNRA)
    #%%
    #***********Normalización 2(SNR negativo) del ruido artefacto********
        if letra=='b':
            ruidoAN2 = (ruido_artefacto*1.5)/14.5 #Normalización
            plt.figure(figsize=(12, 6))
            plt.plot(ruidoAN,color='purple')
            plt.title('Ruido artefacto normalizado (caso 2)')
            plt.grid(True)
            
            #Sumar la señal original con el ruido artefacto normalizado
            senal_ra2 = ruidoAN2 + a
            plt.figure(figsize=(12,6))
            plt.plot(senal_ra2,color='purple')
            plt.title('Señal contaminada con ruido artefacto normalizado (caso 2)')
            plt.grid(True)
            plt.show()
            
            #Hallar las potencias
            prA2 = (sum(ruidoAN2**2))/datos
            g = ps/prA2
            
            print("La potencia del ruido artefacto normalizado (caso 2) es:",prA2)
            
            #Cálculo de la relación señal-ruido
            SNRA2 = 10* math.log10(g)
            print("La relación señal-ruido(SNR), usando ruido artefacto normalizado (caso 2) es:", SNRA2)